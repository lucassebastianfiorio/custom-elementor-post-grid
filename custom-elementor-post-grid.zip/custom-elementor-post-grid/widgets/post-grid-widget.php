<?php

if (! defined('ABSPATH')) exit; // Exit if accessed directly

class Custom_Elementor_Post_Grid_Widget extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'post_grid';
    }

    public function get_title()
    {
        return __('Post Grid', 'custom-elementor-post-grid');
    }

    public function get_icon()
    {
        return 'eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['basic'];
    }

    protected function _register_controls()
    {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Contenido', 'custom-elementor-post-grid'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts por página', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => __('Columnas', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '2' => __('2 Columnas', 'custom-elementor-post-grid'),
                    '3' => __('3 Columnas', 'custom-elementor-post-grid'),
                    '4' => __('4 Columnas', 'custom-elementor-post-grid'),
                ],
            ]
        );

        $this->add_control(
            'show_categories',
            [
                'label' => __('Mostrar Categorías', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Mostrar', 'custom-elementor-post-grid'),
                'label_off' => __('Ocultar', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_tags',
            [
                'label' => __('Mostrar Tags', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Mostrar', 'custom-elementor-post-grid'),
                'label_off' => __('Ocultar', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Mostrar Extracto', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Mostrar', 'custom-elementor-post-grid'),
                'label_off' => __('Ocultar', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __('Longitud del Extracto', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 20,
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label' => __('Mostrar Botón Leer Más', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Mostrar', 'custom-elementor-post-grid'),
                'label_off' => __('Ocultar', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => __('Texto del Botón Leer Más', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Leer Más', 'custom-elementor-post-grid'),
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'link_title',
            [
                'label' => __('Enlazar Título', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sí', 'custom-elementor-post-grid'),
                'label_off' => __('No', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'link_meta',
            [
                'label' => __('Enlazar Meta', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sí', 'custom-elementor-post-grid'),
                'label_off' => __('No', 'custom-elementor-post-grid'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'title_tag',
            [
                'label' => __('Etiqueta del Título', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'h1',
                'options' => [
                    'h1' => __('H1', 'custom-elementor-post-grid'),
                    'h2' => __('H2', 'custom-elementor-post-grid'),
                    'h3' => __('H3', 'custom-elementor-post-grid'),
                    'h4' => __('H4', 'custom-elementor-post-grid'),
                    'h5' => __('H5', 'custom-elementor-post-grid'),
                    'h6' => __('H6', 'custom-elementor-post-grid'),
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'box_style_section',
            [
                'label' => __('Estilos de la Caja', 'custom-elementor-post-grid'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'box_background_color',
            [
                'label' => __('Color de Fondo', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'box_padding',
            [
                'label' => __('Padding', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'box_border_radius',
            [
                'label' => __('Radio del Borde', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-item' => 'border-top-left-radius: {{TOP}}{{UNIT}}; border-top-right-radius: {{RIGHT}}{{UNIT}}; border-bottom-right-radius: {{BOTTOM}}{{UNIT}}; border-bottom-left-radius: {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => __('Sombra de la Caja', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .post-item',
            ]
        );

        $this->add_control(
            'box_margin',
            [
                'label' => __('Margen', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'read_more_button_style_section',
            [
                'label' => __('Estilos del Botón Leer Más', 'custom-elementor-post-grid'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_color',
            [
                'label' => __('Color del Botón', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_background_color',
            [
                'label' => __('Color de Fondo del Botón', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .read-more' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'read_more_button_typography',
                'label' => __('Tipografía del Botón', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .read-more',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'read_more_button_border',
                'label' => __('Borde del Botón', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .read-more',
            ]
        );

        $this->add_control(
            'read_more_button_border_radius',
            [
                'label' => __('Radio del Borde del Botón', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'read_more_button_box_shadow',
                'label' => __('Sombra del Botón', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .read-more',
            ]
        );

        $this->add_control(
            'read_more_button_padding',
            [
                'label' => __('Padding del Botón', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_margin',
            [
                'label' => __('Margen', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();



        $this->start_controls_section(
            'content_style_section',
            [
                'label' => __('Estilos del Contenido', 'custom-elementor-post-grid'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color del Título', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-item h3' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Color del Extracto', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-item .post-excerpt' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => __('Color de Meta', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-item .post-meta' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'fallback_image',
            [
                'label' => __('Imagen de Fallback', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_border_radius_top',
            [
                'label' => __('Radio del Borde Superior de la Imagen', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-item img' => 'border-top-left-radius: {{SIZE}}{{UNIT}}; border-top-right-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_border_radius_bottom',
            [
                'label' => __('Radio del Borde Inferior de la Imagen', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-item img' => 'border-bottom-left-radius: {{SIZE}}{{UNIT}}; border-bottom-right-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_margin',
            [
                'label' => __('Margen del Contenido', 'custom-elementor-post-grid'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .post-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'name' => 'title_typography',
            'label' => __('Tipografía del Título', 'custom-elementor-post-grid'),
            'selector' => '{{WRAPPER}} .post-item .post-title',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'label' => __('Tipografía del Extracto', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .post-item .post-excerpt',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'meta_typography',
                'label' => __('Tipografía de Meta', 'custom-elementor-post-grid'),
                'selector' => '{{WRAPPER}} .post-item .post-meta',
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $query = new WP_Query([
            'post_type' => 'post',
            'posts_per_page' => $settings['posts_per_page'],
        ]);

        if ($query->have_posts()) {
            echo '<div class="custom-post-grid columns-' . esc_attr($settings['columns']) . '">';
            while ($query->have_posts()) {
                $query->the_post();
                echo '<div class="post-item">';
                echo '<a href="' . get_permalink() . '">';
                if (has_post_thumbnail()) {
                    the_post_thumbnail('medium');
                } else {
                    echo '<img src="' . esc_url($settings['fallback_image']['url']) . '" alt="' . esc_attr(get_the_title()) . '" />';
                }
                echo '</a>';
                $title_tag = $settings['title_tag'];
                if ('yes' === $settings['link_title']) {
                    echo '<a href="' . get_permalink() . '" class="post-title"><' . $title_tag . '>' . get_the_title() . '</' . $title_tag . '></a>';
                } else {
                    echo '<' . $title_tag . ' class="post-title">' . get_the_title() . '</' . $title_tag . '>';
                }
                echo '<div class="post-meta">';
                if ('yes' === $settings['show_categories']) {
                    if ('yes' === $settings['link_meta']) {
                        echo '<span class="post-categories">' . get_the_category_list(', ') . '</span>';
                    } else {
                        echo '<span class="post-categories">' . strip_tags(get_the_category_list(', ')) . '</span>';
                    }
                }
                if ('yes' === $settings['show_tags']) {
                    if ('yes' === $settings['link_meta']) {
                        echo '<span class="post-tags">' . get_the_tag_list('', ', ') . '</span>';
                    } else {
                        echo '<span class="post-tags">' . strip_tags(get_the_tag_list('', ', ')) . '</span>';
                    }
                }
                echo '</div>';
                if ('yes' === $settings['show_excerpt']) {
                    $excerpt = wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], '...');
                    echo '<div class="post-excerpt">' . $excerpt . '</div>';
                }
                if ('yes' === $settings['show_read_more']) {
                    echo '<a class="read-more" href="' . get_permalink() . '">' . esc_html($settings['read_more_text']) . '</a>';
                }
                echo '</div>';
            }
            echo '</div>';
            wp_reset_postdata();
        } else {
            echo '<p>' . __('No hay posts disponibles.', 'custom-elementor-post-grid') . '</p>';
        }
    }
}
