<?php
/**
 * Plugin Name: Custom Elementor Post Grid
 * Description: Añade un widget a Elementor para mostrar un grid de posts.
 * Version: 1.0
 * Author: Lucas S. Fiorio
 * Text Domain: custom-elementor-post-grid
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Registrar el widget al inicializar Elementor
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    require_once __DIR__ . '/widgets/post-grid-widget.php';
    $widgets_manager->register( new \Custom_Elementor_Post_Grid_Widget() );
} );

// Cargar estilos y scripts
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style( 'custom-post-grid-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
    wp_enqueue_script( 'custom-post-grid-script', plugin_dir_url( __FILE__ ) . 'assets/js/script.js', [ 'jquery' ], '1.0', true );
} );


